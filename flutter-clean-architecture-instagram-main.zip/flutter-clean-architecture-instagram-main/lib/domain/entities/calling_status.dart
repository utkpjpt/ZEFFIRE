class UsersInfoInCallingRoom {
  String? name, userId, profileImageUrl;
  UsersInfoInCallingRoom({this.name, this.userId, this.profileImageUrl});
}
