class RegisteredUser {
  String email;
  String password;

  RegisteredUser({this.email = "", this.password = ""});
}
