class FollowerUserInfo {
  String followerId;
  String name;
  String profileImageUrl;
  String userName;

  FollowerUserInfo({
    this.followerId = "",
    this.name = "",
    this.profileImageUrl = "",
    this.userName = "",
  });
}
