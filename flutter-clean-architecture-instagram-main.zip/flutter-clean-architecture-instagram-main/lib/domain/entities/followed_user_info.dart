class FollowedUserInfo {
  String followedId;
  String name;
  String profileImageUrl;
  String userName;

  FollowedUserInfo({
    this.followedId = "",
    this.name = "",
    this.profileImageUrl = "",
    this.userName = "",
  });
}
