String myPersonalId = '';
bool isThatMobile = true;
bool isThatAndroid = true;
bool amICalling = false;
bool isMyInfoInReelTimeReady = false;
